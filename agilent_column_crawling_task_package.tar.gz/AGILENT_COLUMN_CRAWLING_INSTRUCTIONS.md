# Agilent色谱柱产品爬取任务指令

**任务编号**: ROWELL-CRAWL-009  
**任务类型**: 色谱柱产品数据爬取  
**优先级**: 🔴 高  
**预期时间**: 1-2小时  
**生成日期**: 2025-11-08

---

## 📊 任务概览

### 目标

从Agilent官网爬取**148个色谱柱产品**的详细信息，包括产品名称、描述、规格参数等。

### 预期成果

| 指标 | 目标值 |
|------|--------|
| **目标产品数** | 148个 |
| **预期成功率** | 95-98% |
| **预期成功产品数** | 141-145个 |
| **平均规格字段数** | 10-15个 |
| **描述覆盖率** | 95%+ |
| **A/B级描述比例** | 60-70% |

### 为什么只爬取148个产品？

原始产品清单包含623个产品，但经过分析：
- **色谱柱产品**: 148个 ✅（本次爬取目标）
- **配件/耗材**: 383个（暂不爬取，规格字段少）
- **其他产品**: 92个（暂不爬取）

**策略**: 优先爬取高质量的色谱柱产品，暂缓配件/耗材爬取。

---

## 📂 交付文件

### 输入文件

1. **产品清单**: `/home/ubuntu/upload/agilent_columns_only.csv`
   - 包含148个色谱柱产品
   - 字段: `productId`, `partNumber`, `brand`, `name`

### 输出文件（需要交付）

1. **爬取结果CSV**: `agilent_columns_crawl_results.csv`
   - 必需字段: 见下方"数据格式要求"
   
2. **质量报告**: `agilent_columns_quality_report.md`
   - 成功率统计
   - 数据质量分析
   - 失败产品清单

3. **爬虫源代码**: `agilent_columns_crawler.py`（可选，便于调试）

---

## 🎯 技术实施方案

### 1. URL构建规则

**已验证有效**（基于之前的测试）：

```
https://www.agilent.com/store/en_US/Prod-{partNumber}/{partNumber}
```

**示例**:
- Part Number: `122-10AE`
- URL: `https://www.agilent.com/store/en_US/Prod-122-10AE/122-10AE`

### 2. 页面结构

所有Agilent产品页面结构一致：

| 元素 | 位置 | 提取方法 |
|------|------|---------|
| **产品名称** | `<h1>` tag | 直接提取文本 |
| **产品描述** | 产品名称下方段落 | 提取第一个段落 |
| **规格表格** | Specifications表格 | 提取所有行的key-value对 |
| **产品图片** | `<img>` tag | 提取src属性 |

### 3. 数据提取策略

#### 3.1 产品名称
```python
def extract_name(soup):
    h1 = soup.find('h1')
    if h1:
        return h1.get_text().strip()
    return None
```

#### 3.2 产品描述
```python
def extract_description(soup):
    # 查找产品名称下方的第一个段落
    # 通常包含产品的详细说明和应用场景
    # 示例: "This is the most common GC column format..."
    return description
```

#### 3.3 规格表格
```python
def extract_specifications(soup):
    specs = {}
    spec_table = soup.find('table') or soup.find('div', class_='specifications')
    
    if spec_table:
        rows = spec_table.find_all('tr')
        for row in rows:
            cells = row.find_all('td')
            if len(cells) >= 2:
                key = cells[0].get_text().strip()
                value = cells[1].get_text().strip()
                specs[key] = value
    
    return specs
```

### 4. 关键规格字段

根据之前的测试，Agilent色谱柱产品通常包含以下规格字段：

**GC色谱柱**（10-15个字段）:
- `Inner Diameter (ID)` - 内径
- `Length` - 长度
- `Film Thickness` - 膜厚
- `Phase` - 固定相
- `Polarity` - 极性
- `Temperature Range` - 温度范围
- `USP Designation` - USP编号
- `Capillary Tubing` - 材料
- `Format` - 格式
- `With Smart Key` - 是否带Smart Key

**HPLC色谱柱**（8-12个字段）:
- `Inner Diameter` - 内径
- `Length` - 长度
- `Particle Size` - 粒径
- `Pore Size` - 孔径
- `Phase` - 固定相
- `pH Range` - pH范围
- `Temperature Range` - 温度范围
- `USP Code` - USP编号

---

## 📋 数据格式要求

### CSV文件格式

**文件名**: `agilent_columns_crawl_results.csv`

**必需字段**:

| 字段名 | 类型 | 说明 | 示例 |
|--------|------|------|------|
| `productId` | string | 产品ID（来自输入CSV） | `AGIL-122-10AE` |
| `partNumber` | string | 零件号（来自输入CSV） | `122-10AE` |
| `brand` | string | 品牌（固定为"Agilent"） | `Agilent` |
| `name` | string | 产品名称 | `J&W DB-1 GC Column, 100 m, 0.25 mm, 0.50 µm` |
| `description` | string | 产品描述（200-500字符） | `This is the most common GC column format...` |
| `descriptionQuality` | string | 描述质量等级 | `high` / `medium` / `low` / `none` |
| `specifications` | JSON string | 规格参数（JSON格式） | `{"Inner Diameter": "0.25 mm", "Length": "100 m", ...}` |
| `imageUrl` | string | 产品图片URL（可选） | `https://...` |
| `catalogUrl` | string | 产品页面URL | `https://www.agilent.com/store/...` |
| `technicalDocUrl` | string | 技术文档URL（可选） | `https://...` |
| `crawlStatus` | string | 爬取状态 | `success` / `failed` |
| `failureReason` | string | 失败原因（如果失败） | `404` / `timeout` / `parse_error` |

### 描述质量等级标准

| 等级 | 描述长度 | 说明 |
|------|---------|------|
| `high` | ≥200字符 | 详细描述，包含应用场景、技术特点 |
| `medium` | 100-199字符 | 中等描述，包含基本信息 |
| `low` | 50-99字符 | 简短描述 |
| `none` | <50字符 | 无描述或描述过短 |

### Specifications JSON格式

```json
{
  "Inner Diameter": "0.25 mm",
  "Length": "100 m",
  "Film Thickness": "0.50 µm",
  "Phase": "DB-1",
  "Polarity": "Nonpolar",
  "Temperature Range": "-60 °C to 325/350 °C",
  "USP Designation": "G2",
  "Capillary Tubing": "Fused Silica",
  "Format": "7 inch cage",
  "With Smart Key": "No",
  "UNSPSC Code": "41115710"
}
```

**注意事项**:
1. 保留原始字段名（不要翻译）
2. 保留原始单位（mm, µm, °C等）
3. 如果某个字段不存在，不要包含在JSON中
4. 确保JSON格式正确（可以被`JSON.parse()`解析）

---

## 🚀 执行流程

### Phase 1: 环境准备（5分钟）

1. 安装依赖包
```bash
pip install requests beautifulsoup4 pandas
```

2. 验证产品清单
```python
import pandas as pd
df = pd.read_csv('agilent_columns_only.csv')
print(f"Total products: {len(df)}")  # 应该是148
```

### Phase 2: 小规模测试（15分钟）

1. 先测试10个产品
2. 验证URL构建规则
3. 验证数据提取逻辑
4. 检查成功率（应该≥90%）

**如果测试成功率<90%**:
- 停止爬取
- 分析失败原因
- 调整策略后重新测试

### Phase 3: 批量爬取（1-1.5小时）

1. 使用线程池并发爬取（建议5-10个线程）
2. 设置请求间隔（2-3秒，遵守爬虫礼仪）
3. 每50个产品输出进度报告
4. 记录失败产品

**进度监控示例**:
```
Progress: 50/148 (33.8%)
Success rate: 48/50 (96.0%)
Average spec fields: 11.2
```

### Phase 4: 数据清洗和验证（15分钟）

1. 检查必需字段完整性
2. 验证JSON格式正确性
3. 统计数据质量指标
4. 生成质量报告

### Phase 5: 交付（5分钟）

1. 导出CSV文件
2. 生成质量报告
3. 打包交付

---

## ⚠️ 重要注意事项

### 1. 爬虫礼仪

- ✅ 设置User-Agent模拟真实浏览器
- ✅ 设置请求间隔（2-3秒）
- ✅ 遵守robots.txt规则
- ✅ 不要短时间大量请求

### 2. 错误处理

- ✅ 404错误: 记录为失败，继续下一个
- ✅ 超时错误: 重试3次，仍失败则记录
- ✅ 解析错误: 记录错误信息，继续下一个

### 3. 数据质量

- ✅ 优先保证数据准确性，而非速度
- ✅ 如果描述或规格提取失败，不要编造数据
- ✅ 保留原始数据格式（不要翻译或转换单位）

### 4. 法律合规

- ✅ 仅用于学习和研究目的
- ✅ 不用于商业用途
- ✅ 尊重网站版权和服务条款

---

## 📊 质量验证清单

交付前请确认：

- [ ] CSV文件包含所有必需字段
- [ ] 成功率≥95%
- [ ] 描述覆盖率≥90%
- [ ] 平均规格字段数≥8
- [ ] 所有JSON格式正确（可以被解析）
- [ ] 失败产品有明确的失败原因
- [ ] 质量报告包含详细统计数据

---

## 📈 预期成果

### 成功率预测

| 指标 | 预期值 |
|------|--------|
| 总产品数 | 148 |
| 成功产品数 | 141-145 (95-98%) |
| 失败产品数 | 3-7 (2-5%) |

### 数据质量预测

| 指标 | 预期值 |
|------|--------|
| 描述覆盖率 | 95%+ |
| A/B级描述比例 | 60-70% |
| 平均规格字段数 | 10-12 |
| 平均描述长度 | 150-200字符 |

### 时间预测

| 阶段 | 时间 |
|------|------|
| 环境准备 | 5分钟 |
| 小规模测试 | 15分钟 |
| 批量爬取 | 1-1.5小时 |
| 数据清洗 | 15分钟 |
| 交付 | 5分钟 |
| **总计** | **1.5-2小时** |

---

## 🎯 成功标准

任务被认为成功完成，需要满足：

1. ✅ 成功率≥95%（至少141个产品）
2. ✅ 描述覆盖率≥90%
3. ✅ 平均规格字段数≥8
4. ✅ 所有数据格式正确
5. ✅ 交付完整的质量报告

---

## 📞 支持和反馈

如有任何问题或需要技术支持，请：

1. 检查本指令文档的"常见问题"部分
2. 参考之前的技术实施方案（`Agilent技术实施方案`）
3. 联系任务发布者

---

## 📝 常见问题

### Q1: 如果产品页面404怎么办？

**A**: 这是正常现象（预期2-5%失败率）。记录为失败，在`failureReason`字段填写`404`，继续下一个产品。

### Q2: 如果规格表格格式不一致怎么办？

**A**: Agilent产品页面结构标准化程度高，但如果遇到特殊情况：
1. 尝试多种选择器（`table`, `div.specifications`等）
2. 如果仍无法提取，记录为`parse_error`
3. 继续下一个产品

### Q3: 如果描述过短（<50字符）怎么办？

**A**: 
1. 检查是否提取了正确的段落
2. 如果确实没有更多描述，标记为`descriptionQuality: none`
3. 不要编造或补充描述

### Q4: 是否需要处理重复产品？

**A**: 产品清单已去重，不需要额外处理。但如果发现重复，保留第一个成功爬取的结果。

### Q5: 是否需要下载产品图片？

**A**: 不需要。只需要提取图片URL即可。

---

## 📦 交付清单

请确保交付以下文件：

1. ✅ `agilent_columns_crawl_results.csv` - 爬取结果（141-145个产品）
2. ✅ `agilent_columns_quality_report.md` - 质量分析报告
3. ⭐ `agilent_columns_crawler.py` - 爬虫源代码（可选，便于调试）

---

**任务编号**: ROWELL-CRAWL-009  
**生成日期**: 2025-11-08  
**预期完成时间**: 1.5-2小时  
**优先级**: 🔴 高

**祝爬取顺利！** 🚀
